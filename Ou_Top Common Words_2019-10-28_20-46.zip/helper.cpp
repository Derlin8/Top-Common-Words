#include "helper.h"


void print(multimap<int,string,classcomp> &m , int n){
    /*
      +--------------------------------------+
      |          Print Occurrence            |
      +--------------------------------------+
    */
    int prev = 0;
    int numCounter = 1;
    for( auto s  : m){
        if(n == 0 ) break;
        if(s.first == prev) continue;
        n--;
        if(m.count(s.first) == 1){
            cout << numCounter << ".) These words appeared "
                 << s.first << " times: {"
                 << s.second << "}" << endl;
            numCounter++;
            prev = s.first;
            continue;
        }
        auto walker = m.equal_range(s.first);
        for (auto itr = walker.first; itr != walker.second; ++itr){
            if(itr == walker.first)
                cout << numCounter << ".) These words appeared " << itr->first << " times: {" << itr->second;
            else
                cout << ", " << itr->second;
        }
        cout << "}" << endl;
        numCounter++;
        prev = s.first;
    }
}
void reverse(map<string,int> &m, multimap<int,string , classcomp> &res){
    /*
      +--------------------------------------+
      |             Reverse map              |
      +--------------------------------------+
    */
    map<string,int>::iterator it;
    for(it = m.begin() ; it != m.end() ; it++){
        string first = it->first;
        int second = it->second;
        res.insert(std::pair<int,string>(second,first));
    }
}
void process(char * fileName  , map<string,int> &m ){

    /*
    +--------------------------------------+
    |      READ FILE & Add to MAP          |
    +--------------------------------------+
  */
    string word;
    ifstream filestr (fileName); //declare stream variable name
    //filestr.open(fileName); //open file
   // if (filestr.is_open()) {
        while (filestr >> word) { //if not at end of file, continue reading
            int ptr = 0;
            for(unsigned int i = 0; i < word.size(); ++i)
            {
                //Error here.. build string need to fix
                if (((word[i] >= 'a' && word[i]<='z') || (word[i] >= 'A' && word[i]<='Z') || (i != 0 && word[i] == '\'') || isdigit(word[i])))
                {
                    word[ptr] = tolower(word[i]);
                    ptr++;
                }
            }
                           if(word[ptr-1] == '\'') ptr--;
            string strippedWord = word.substr(0,ptr);
            //a, an, and, in, is, it, the
            if(strippedWord == "a" ||
               strippedWord == "an" ||
               strippedWord == "and" ||
               strippedWord == "in" ||
               strippedWord == "is" ||
               strippedWord == "it" ||
               strippedWord == "the" ||
               strippedWord == "" ) continue;
            auto res = m.find(strippedWord);
            if( res != m.end() ){ //Update
                res->second = res->second + 1;
            }
            else { //Insert New
                m.insert(std::pair<string,int>(strippedWord,1));
            }
        }
        filestr.close();
    //}else {cout << "error opening file";}

}

bool classcomp::operator() (  const int& lhs,  const int& rhs ) const{
    return lhs > rhs;
}
//void topN(string path , string n){
void topN(char * path , int n){

    map<string,int> occurCounter;
    multimap<int , string,classcomp > rev;

    process(path,occurCounter);
    reverse(occurCounter,rev);
    print(rev,n);

}//END topN()


