#include "helper.h"

/*
  Added :
    duplicate detection
    handle uppercase
*/

int main(int argc , char** argv ) {



        if(argc > 2 ){
          std::istringstream iss( argv[2] );
          int val =1;
          iss >> val;
          topN(argv[1],val);

        }else{
          topN(argv[1],10);

        }









  //Pass in path = argv[1] , topN = argv[2]
 // topN(argv[1],argv[2]);
  // topN("shake_my_ass.txt",5);



}
/*
sample OUTPUT
./TopCommonWords shake_it_off.txt 5
1.) These words appeared 78 times: {shake}
2.) These words appeared 70 times: {i}
3.) These words appeared 44 times: {off}
4.) These words appeared 21 times: {gonna}
5.) These words appeared 15 times: {break, fake, hate, play}*/

