#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iterator>
#include <cctype>
#include <vector>
#include <sstream>

using namespace std;


void print(multimap<int,string,bool* > &m , int n);
void reverse(multimap<string,int> &m , multimap<int,string,bool* > &res);
void process(char * fileName , map<string,int> &m );
void topN(char * path, int n);

struct classcomp {
    bool operator() (  const int& lhs,  const int& rhs ) const;
};














